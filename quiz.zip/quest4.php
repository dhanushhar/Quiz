<?php
if(isset($_POST["submit"]))
{
    echo $_POST['blood'] ;
    echo $_POST['blood'];
    if($_POST['blood'] == 'Red')
    {
    header("Location: localhost/quest5.php?user=".$_POST["username"]);
    }
    else
    {
       header("Location: localhost/youlost.php"); 
    }
}

?>

<!DOCTYPE html>
<html>
<body>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" >
<label>4. In which country was first covid-19 patient found?</label><br/>
<input type="hidden" value="<?php echo $_GET['user']; ?>" name="username" />
<input type="radio" name="blood" value="Red">
  <label for="male">China</label><br>
  <input type="radio" name="blood" value="Yellow">
  <label for="female">India</label><br>
  <input type="radio"  name="blood" value="Blue">
  <label for="other">Italy</label><br>
  <input type="radio"  name="blood" value="false">
  <label for="other">France</label><br>
<input type="submit" name="submit" value="next">
</form>
</body>
</html>