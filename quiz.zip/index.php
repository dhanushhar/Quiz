<?php
if(isset($_POST["submit"]))
{
    if(strlen($_POST["fname"])==0)
    {
        echo "<p style='color:red'>Enter your name please*</p><br>";
    }
    else
    {
         header("Location: localhost/quest1.php?user=".$_POST["fname"]);
    }
}
    ?>
<!DOCTYPE html>
<html>
<body>
   
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" >
     <input type="text" name="fname" placeholder="Enter your name"><br>

<input type="submit" name="submit" value="next">
</form>
</body>
</html>
    