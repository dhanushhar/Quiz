<?php
if(isset($_POST["submit"]))
{
    if(isset($_POST["blood"]))
    {
        if($_POST['blood'] == 'Red')
        {
            $servername = "localhost";
            $username = "";
            $password =  "";
            $winner=$_POST["username"];
            $conn = mysqli_connect($servername, $username, $password,$username);
            $sql="insert into winners (winner)
                    VALUES ('$winner')";
            if (mysqli_query($conn, $sql)) 
            {
               header("Location: localhost/winner.php?user=".$_POST["username"]);
            }
            else
            {
              echo "YOU WON" ;  
            }
            
        }
        else
        {
           header("Location: localhost/php/youlost.php"); 
        }
    }
    else
    {
        echo "Please select any option";
    }
}
?>

<!DOCTYPE html>
<html>
<body>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" >
<label>5.Which of the following is a programming language?</label><br/>
<input type="hidden" value="<?php echo $_GET['user']; ?>" name="username" />
<input type="radio" name="blood" value="Green">
  <label for="male">Goa</label><br>
  <input type="radio" name="blood" value="Yellow">
  <label for="female">Picasa</label><br>
  <input type="radio"  name="blood" value="Blue">
  <label for="other">Laurete</label><br>
  <input type="radio"  name="blood" value="Red">
  <label for="other">Java</label><br>
<input type="submit" name="submit" value="next">
</form>
</body>
</html>