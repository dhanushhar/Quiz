<?php

if(isset($_POST["submit"]))
{

        if(isset($_POST["uni"]))
        {
            
            if($_POST['uni'] == 'Red')
            {
            header("Location: localhost/quest2.php?user=".$_POST['username']);
            }
            else
            {
               header("Location: localhost/youlost.php"); 
            }
        }
        else
        {
            echo "<p style='color:red'>Please select any option*</p><br>";
        }
    
}
?>
<!DOCTYPE html>
<html>
<body>
   
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" >
<label>1.Fullform of LPU?</label><br/>
<input type="hidden" value="<?php echo $_GET['user']; ?>" name="username" />
<input type="radio" name="uni" value="false">
  <label for="male">Lovely Perfection University</label><br>
  <input type="radio" name="uni" value="false">
  <label for="female">Loyale Professional University</label><br>
  <input type="radio"  name="uni" value="Red">
  <label for="other">Lovely Professional University</label><br>
  <input type="radio"  name="uni" value="false">
  <label for="other">Lovely Punjab University</label><br>
<input type="submit" name="submit" value="next">
</form>
</body>
</html>