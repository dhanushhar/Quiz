<?php
if(isset($_POST["submit"]))
{
    if(isset($_POST["blood"]))
    {
        if($_POST['blood'] == 'Red')
        {
        header("Location: localhost/quest3.php?user=".$_POST["username"]);
        }
        else
        {
           header("Location: localhost/youlost.php"); 
        }
    }
    else
    {
        echo "Please select any option";
    }
}
?>

<!DOCTYPE html>
<html>
<body>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" >
<label>2.What is the color of the human blood?</label><br/>
<input type="hidden" value="<?php echo $_GET['user']; ?>" name="username" />
<input type="radio" name="blood" value="Green">
  <label for="male">Green</label><br>
  <input type="radio" name="blood" value="Yellow">
  <label for="female">Yellow</label><br>
  <input type="radio"  name="blood" value="Blue">
  <label for="other">Blue</label><br>
  <input type="radio"  name="blood" value="Red">
  <label for="other">Red</label><br>
<input type="submit" name="submit" value="next">
</form>
</body>
</html>